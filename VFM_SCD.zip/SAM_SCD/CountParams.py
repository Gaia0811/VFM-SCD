from models.ResNet_GRU import ResNet_GRU as Net
import torch
from thop import profile

#model = FCN_PAAE(5, num_classes=RS.num_classes+1)
model = Net().cuda()

print("%s | %s" % ("Params(M)", "FLOPs(G)"))
print("---|---|---")
dsize = (1, 3, 512, 512)
x1 = torch.randn(dsize).cuda()
x2 = torch.randn(dsize).cuda()
total_ops, total_params = profile(model, (x1,x2), verbose=False)
print("%.2f | %.2f" % (total_params / (1000 ** 2), total_ops / (1000 ** 3)))